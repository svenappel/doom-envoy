#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
exec "$DIR/lib/ld-linux-armhf.so.3" --library-path "$DIR/lib" "$DIR/bin/doomgeneric" -iwad "$DIR/doom.wad" "$@"
