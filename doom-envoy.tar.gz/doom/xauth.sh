#!/bin/sh
exec /tmp/doom/lib/ld-linux-armhf.so.3 --library-path /tmp/doom/lib /tmp/doom/bin/xauth "$@"
