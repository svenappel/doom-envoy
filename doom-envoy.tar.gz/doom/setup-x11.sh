#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /usr/X11R6/bin
ln -sf "$DIR/xauth.sh" /usr/X11R6/bin/xauth
sed -i 's/X11Forwarding no/X11Forwarding yes/' /etc/ssh/sshd_config
/etc/init.d/ssh restart
echo "Done. Reconnect with: ssh -X -i ~/.ssh/id_ed25519 root@<gateway-ip>"
