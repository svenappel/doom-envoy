#!/bin/sh
# Eenmalig uitvoeren op de gateway als root
DIR="$(cd "$(dirname "$0")" && pwd)"
ln -sf "$DIR/xauth.sh" /usr/bin/xauth
sed -i 's/X11Forwarding no/X11Forwarding yes/' /etc/ssh/sshd_config
service ssh restart
echo "Klaar. Verbind opnieuw met: ssh -X -i ~/.ssh/id_ed25519 root@<gateway>"
